# HRMS AI Service

AI-powered backend service for natural language querying of HRMS APIs and HR policy documents.

## Current Project Status

This is the status based on a full code scan of the repository.

- Service architecture: implemented and runnable (FastAPI + routing + LLM + vector retrieval + caching)
- API health endpoint: implemented
- Chat endpoint: implemented with source attribution support
- Policy RAG pipeline: implemented with PDF extraction, OCR fallback, and Chroma indexing
- Tool/API selection pipeline: implemented with domain classification + hybrid scoring + optional LLM tie-break
- Redis cache: implemented with graceful fallback when Redis is unavailable
- Code diagnostics: no active Python errors detected in workspace scan
- Test suite: not present in repository

Operational maturity summary:

- Good: modular structure, clear pipeline separation, fallback handling in several components
- Needs strengthening for production hardening: tests, stronger observability, source metadata caching strategy, and stricter API/tool validation controls

## What the Service Does

The service answers natural language HR questions by routing to one of two paths:

1. Policy path (RAG)
2. Data path (live HRMS API execution)

It supports:

- Intent routing (policy vs data)
- Domain classification for API/tool narrowing
- Hybrid API selection (semantic + keyword + optional LLM arbitration)
- API execution against configured HRMS base URL
- Policy text retrieval from API payload or PDF content
- Chroma-based retrieval for policy context
- LLM-based final answer generation
- Response source attribution in both chat answer and dedicated source field

## High-Level Request Flow

1. Client calls POST /chat with a question.
2. Route handler delegates to rag_engine.answer_question.
3. Cache lookup is attempted first.
4. Query router decides policy or data path.
5. Policy path:
   - Fetch policy payload from HRMS API
   - Select best policy candidate
   - Retrieve existing chunks or ingest policy text/PDF into vector DB
   - Retrieve top chunks and generate answer
6. Data path:
   - Classify domain
   - Select API from registry using hybrid scoring
   - Validate selected tool
   - Extract simple entities (id)
   - Execute HRMS API call
   - Parse response and generate final answer
7. Source attribution is formatted and returned.

## API Endpoints

### GET /health

Returns service liveness:

```json
{
  "status": "ok"
}
```

### POST /chat

Request:

```json
{
  "question": "Show me all departments"
}
```

Response shape:

```json
{
  "answer": "...final answer...\nSource: GET /api/Department",
  "source": "Source: GET /api/Department"
}
```

For policy responses, source appears as policy title (and page when available).

## Source Attribution Behavior

Attribution formatting is handled centrally in the RAG engine.

- Policy source example: Source: Leave Policy (Page 3)
- API source example: Source: GET /api/Department

Notes:

- Chat route appends source text to the answer when present
- Response also includes a separate source field
- Cached answers may return without source metadata depending on cache path

## Components and Responsibilities

### Application and API Layer

- app/main.py
  - Creates FastAPI app
  - Registers chat and health routers
  - Serves static UI at root and under /static
- app/api/routes/chat.py
  - Accepts chat requests
  - Calls rag_engine.answer_question
  - Formats and returns source attribution
- app/api/routes/health.py
  - Basic health endpoint
- app/api/schemas/chat_schema.py
  - Request schema
- app/api/schemas/response_schema.py
  - Response schema

### Core Orchestration

- app/core/rag_engine.py
  - Primary orchestrator for cache, route, answer generation, source formatting
- app/core/query_router.py
  - Routes question to policy or data path
- app/core/intent_classifier.py
  - LLM intent classifier used by query router
- app/core/domain_classifier.py
  - LLM domain classifier used by tool planner
- app/core/agent_router.py
  - Data-path orchestration: tool select, validate, execute, parse, answer
- app/core/tool_planner.py
  - Loads API registry
  - Domain filtering
  - Semantic retrieval from api_tools vector collection
  - Keyword boost and thresholding
  - Optional LLM disambiguation for close candidates
- app/core/tool_validator.py
  - Basic tool schema checks
- app/core/tool_executor.py
  - Executes selected tool (currently GET-only)
- app/core/entity_extractor.py
  - Extracts numeric id from user question
- app/core/context_builder.py
  - In-memory rolling conversation context

### Policy and Vector Retrieval

- app/core/policy_service.py
  - Fetches policy payload from HRMS API
  - Detects text, URL PDFs, binary PDFs, base64 PDFs
  - Extracts text via pypdf first, then OCR fallback (PyMuPDF + pytesseract + Pillow)
  - Chunks and indexes matched policy content into hrms_documents collection
  - Retrieves relevant chunks and source metadata
- app/vectordb/chroma_client.py
  - Persistent Chroma client and collection factory
- app/vectordb/retriever.py
  - Vector query helper with optional metadata return
- app/vectordb/api_vector_store.py
  - Registry tool indexing, stale deletion, semantic tool search with scores

### LLM, Embeddings, External Services

- app/llm/llama_client.py
  - Ollama generate wrapper
  - API-response-to-answer generation helper
- app/llm/prompts.py
  - System prompt template
- app/llm/response_parser.py
  - Converts API payloads into flattened text for LLM
- app/embeddings/embedding_model.py
  - SentenceTransformer wrapper
- app/embeddings/chunking.py
  - Fixed-window chunking with overlap
- app/services/hrms_api_client.py
  - HRMS API GET wrapper, policy fetch, binary downloader

### Caching and Static UI

- app/cache/redis_cache.py
  - Normalized-key Redis cache with TTL
  - Graceful disabled mode if Redis unavailable
- app/static/chat-ui.html
  - Browser chat interface
  - Source badge rendering
  - PDF export for chat transcript

### Tool Registry and Scripts

- app/tools/api_registry.json
  - API registry consumed by planner and vector indexing
  - Includes normalized_name and normalized_intent fields for improved matching/routing
- scripts/build_registry.py
  - Generates registry from Swagger (basic scaffolding utility)
- scripts/index_api_registry.py
  - Validates and syncs registry into Chroma api_tools collection
  - Supports watch mode

## Configuration

Environment variables loaded from project root .env:

- OLLAMA_URL
- LLM_MODEL
- EMBED_MODEL
- CHROMA_PATH
- HRMS_API_BASE_URL
- HRMS_API_TOKEN
- REDIS_HOST (default localhost)
- REDIS_PORT (default 6379)
- SEMANTIC_SEARCH_K (default 10)
- KEYWORD_WEIGHT (default 0.5)
- SIMILARITY_THRESHOLD (default 0.2)
- REQUIRE_HIGH_CONFIDENCE (default true)

## Setup and Run

Prerequisites:

- Python 3.11+
- Redis
- Ollama
- Tesseract OCR binary installed on host (for OCR fallback path)

Install:

```bash
python3.11 -m venv venv
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
```

Run dependencies:

```bash
ollama serve
```

```bash
redis-server
```

Run API:

```bash
source venv/bin/activate
uvicorn app.main:app --reload
```

Quick checks:

```bash
curl http://localhost:8000/health
```

```bash
curl -X POST "http://localhost:8000/chat" \
  -H "Content-Type: application/json" \
  -d '{"question":"What is the leave policy?"}'
```

## Logging Notes

Expected runtime logs include:

- RAG Cache HIT or MISS
- Agent Cache HIT or MISS
- Query route: policy or data
- Planner diagnostics for candidates and selected tool
- Outgoing ToolExecutor API URL

## Known Gaps and Risks

1. No automated tests in repository (unit, integration, or load tests).
2. Source metadata is not always preserved on cache hits.
3. Tool execution currently supports GET only.
4. Conversation history is in-memory only (not durable across restarts).
5. LLM outputs are minimally guarded; schema-constrained outputs would improve stability.
6. Registry quality directly impacts selection quality; re-indexing is required after registry changes.

## Suggested Immediate Next Improvements

1. Add unit tests for planner, policy extraction, and routing.
2. Cache structured payload containing answer plus source metadata.
3. Add stricter response parsing/validation for LLM classifiers.
4. Add request timeouts/retry strategy in ToolExecutor.
5. Add observability (request IDs, structured logs, error categories, metrics).

## Repository Layout

```text
hrms_ai_service/
├── app/
│   ├── api/
│   ├── cache/
│   ├── core/
│   ├── embeddings/
│   ├── llm/
│   ├── services/
│   ├── static/
│   ├── tools/
│   ├── vectordb/
│   ├── config.py
│   └── main.py
├── scripts/
├── chroma_db/
├── requirements.txt
└── README.md
```

### `venv/`

Local virtual environment (dependencies and third-party files).

## Common Commands

## Activate Environment

```bash
source venv/bin/activate
```

## Run Server

```bash
uvicorn app.main:app --reload
```

## Rebuild API Registry (if APIs changed)

```bash
python scripts/build_registry.py
python scripts/index_api_registry.py
```

Alternative from inside `scripts/`:

```bash
python build_registry.py
python index_api_registry.py
```

## Open Swagger Docs

- http://localhost:8000/docs

## Troubleshooting

- `zsh: command not found: rg`
  - Install ripgrep or use `find` as fallback.
- `Connection refused` on `/chat`
  - Ensure `uvicorn` is running on expected port.
- Empty/weak answers for policy queries
  - Verify policy data is indexed in ChromaDB.
- API-related errors
  - Check `HRMS_API_BASE_URL` and `HRMS_API_TOKEN`.
- Slow first response
  - First LLM/embedding call is usually slower due to warm-up.

## Current Documentation Policy

All project documentation is consolidated into this single `README.md`.
Separate project Markdown docs were removed to keep one canonical source of truth.
